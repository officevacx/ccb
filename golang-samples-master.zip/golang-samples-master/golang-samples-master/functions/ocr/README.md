<img src="https://avatars2.githubusercontent.com/u/2810941?v=3&s=96" alt="Google Cloud Platform logo" title="Google Cloud Platform" align="right" height="96" width="96"/>

# Google Cloud Functions - OCR (Optical Character Recognition) sample

See:

* [Cloud Functions OCR tutorial][tutorial]
* [Cloud Functions OCR sample source code][code]

[tutorial]: https://cloud.google.com/functions/docs/tutorials/ocr
[code]: app/
