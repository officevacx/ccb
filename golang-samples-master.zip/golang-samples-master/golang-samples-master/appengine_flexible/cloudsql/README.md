## Google Cloud SQL on App Engine flexible environment

Follow the [instructions][1] in the documentation to run this code.

[1]: https://cloud.google.com/appengine/docs/flexible/go/using-cloud-sql
